package ExampleJava;

public class Addition {
	public static int add(int firstNum, int secondNum) {
		int c= firstNum+secondNum;
		return c;
	}}
		
	

